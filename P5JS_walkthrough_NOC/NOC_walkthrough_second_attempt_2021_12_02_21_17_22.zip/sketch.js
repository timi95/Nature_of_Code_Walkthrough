function setup() { 
}

function draw() {
  createCanvas(windowWidth, 400);
   
}
